<?php
// db_connect.php

$host = "localhost";
$user = "root"; // Default XAMPP MySQL user
$password = ""; // Default XAMPP MySQL password is usually blank
$dbname = "aquatrack_db"; // Make sure this perfectly matches your DB name

// Create connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>