<?php
header("Access-Control-Allow-Origin: *");
// Added OPTIONS to allowed methods for browser preflight checks
header("Access-Control-Allow-Methods: POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// Handle the CORS preflight check safely
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once 'db_connect.php';

// Read the JSON data sent from React
$data = json_decode(file_get_contents("php://input"));

if(!empty($data->email) && !empty($data->password) && !empty($data->name)) {
    
    // Prepare the SQL insert
    $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, address, barangay, landmark, phone_number, role) VALUES (?, ?, ?, ?, ?, ?, ?, 'Customer')");
    $stmt->bind_param("sssssss", $data->name, $data->email, $data->password, $data->address, $data->barangay, $data->landmark, $data->phone);

    // Use a try-catch block to handle the duplicate email crash gracefully
    try {
        if($stmt->execute()) {
            // Grab the ID of the user we just created
            $newUserId = $stmt->insert_id;
            
            // Package it up to send back to React to log them in immediately
            $user = array(
                "id" => $newUserId, 
                "name" => $data->name, 
                "email" => $data->email, 
                "role" => "customer"
            );
            echo json_encode(array("success" => true, "user" => $user));
        }
    } catch (mysqli_sql_exception $e) {
        // Error code 1062 is MySQL's specific code for "Duplicate Entry"
        if ($e->getCode() == 1062) {
            echo json_encode(array("success" => false, "message" => "That email is already registered!"));
        } else {
            // For any other random database errors
            echo json_encode(array("success" => false, "message" => "Database error occurred."));
        }
    }
} else {
    echo json_encode(array("success" => false, "message" => "Incomplete data."));
}
?>