<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

include_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->email) && !empty($data->password)) {
    // Look for the user
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
    $stmt->bind_param("ss", $data->email, $data->password);
    $stmt->execute();
    $result = $stmt->get_result();

    // If we found a match
    if($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Return their info (but don't send the password back!)
        $user = array(
            "id" => $row['user_id'],
            "name" => $row['fullname'],
            "email" => $row['email'],
            "role" => strtolower($row['role'])
        );
        echo json_encode(array("success" => true, "user" => $user));
    } else {
        echo json_encode(array("success" => false, "message" => "Invalid email or password."));
    }
} else {
    echo json_encode(array("success" => false, "message" => "Please fill in all fields."));
}
?>