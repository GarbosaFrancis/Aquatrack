<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include_once 'db_connect.php';

// Fetch ALL orders, plus the customer's name, and the assigned rider's name
// Fetch ALL orders, plus the customer's full details, and the assigned rider's name
$sql = "SELECT o.*, c.fullname AS customer_name, c.phone_number, c.email, c.address, c.barangay, c.landmark, r.fullname AS rider_name 
        FROM orders o 
        JOIN users c ON o.user_id = c.user_id 
        LEFT JOIN users r ON o.rider_id = r.user_id 
        ORDER BY o.order_date DESC";
$result = $conn->query($sql);

$orders = array();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}
echo json_encode($orders);
?>