<?php
// get_orders.php

// 1. Allow Vite to access this PHP file (Bypass CORS blocking)
header("Access-Control-Allow-Origin: *"); 
header("Content-Type: application/json; charset=UTF-8");

// 2. Bring in the database connection
include_once 'db_connect.php';

// 3. Write your SQL query (fetching basic order info)
$sql = "SELECT order_id, user_id, status, total_amount, order_date FROM orders ORDER BY order_date DESC";
$result = $conn->query($sql);

$orders = array();

// 4. Loop through the results and add them to our array
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}

// 5. Convert the PHP array into JSON and output it
echo json_encode($orders);

$conn->close();
?>