<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

include_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->userId) && isset($data->total)) {
    // Map the React order type to your database ENUM
    $orderType = ($data->orderType == 'pickup') ? 'Store Pickup' : 'Delivery';

    $stmt = $conn->prepare("INSERT INTO orders (user_id, order_type, subtotal, delivery_fee, total_amount, payment_method, status) VALUES (?, ?, ?, ?, ?, ?, 'Pending')");
    $stmt->bind_param("isddds", $data->userId, $orderType, $data->subtotal, $data->deliveryFee, $data->total, $data->paymentMethod);

    if($stmt->execute()) {
        $orderId = $stmt->insert_id;
        
        // Format the new order so React can display it instantly without refreshing the page
        $newOrder = array(
            "id" => $orderId,
            "userId" => $data->userId,
            "status" => "pending",
            "total" => $data->total,
            "orderType" => $data->orderType
        );

        echo json_encode(array("success" => true, "newOrder" => $newOrder));
    } else {
        echo json_encode(array("success" => false, "message" => "Failed to save order."));
    }
} else {
    echo json_encode(array("success" => false, "message" => "Missing order details."));
}
?>