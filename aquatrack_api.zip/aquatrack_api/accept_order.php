<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once 'db_connect.php';
$data = json_decode(file_get_contents("php://input"));

if(!empty($data->order_id) && !empty($data->rider_id)) {
    // Update the order with the rider's ID and change status
    $stmt = $conn->prepare("UPDATE orders SET rider_id = ?, status = 'Out for Delivery' WHERE order_id = ?");
    $stmt->bind_param("ii", $data->rider_id, $data->order_id);
    
    if($stmt->execute()) {
        echo json_encode(array("success" => true));
    } else {
        echo json_encode(array("success" => false, "message" => "Database update failed"));
    }
} else {
    echo json_encode(array("success" => false, "message" => "Missing data"));
}
?>