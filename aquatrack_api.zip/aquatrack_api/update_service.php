<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') { http_response_code(200); exit(); }

include_once 'db_connect.php';
$data = json_decode(file_get_contents("php://input"));

if(!empty($data->service_id)) {
    $stmt = $conn->prepare("UPDATE services SET service_name = ?, price = ?, is_active = ?, image_url = ? WHERE service_id = ?");
    $isActive = $data->is_active ? 1 : 0;
    $stmt->bind_param("sdisi", $data->service_name, $data->price, $isActive, $data->image_url, $data->service_id);
    
    if($stmt->execute()) {
        echo json_encode(array("success" => true));
    } else {
        echo json_encode(array("success" => false, "message" => "Update failed"));
    }
}
?>