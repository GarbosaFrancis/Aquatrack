<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include_once 'db_connect.php';

// Fetch delivery orders AND the customer's address from the users table
$sql = "SELECT o.*, u.fullname, u.phone_number, u.address, u.barangay, u.landmark 
        FROM orders o 
        JOIN users u ON o.user_id = u.user_id 
        WHERE o.order_type = 'Delivery' 
        AND o.status = 'Pending' 
        AND o.rider_id IS NULL 
        ORDER BY o.order_date ASC";
$result = $conn->query($sql);

$orders = array();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}
echo json_encode($orders);
?>