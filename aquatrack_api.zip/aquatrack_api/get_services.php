<?php
// 1. Allow Vite to talk to this file
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once 'db_connect.php';

// 2. Fetch all services
$sql = "SELECT * FROM services";
$result = $conn->query($sql);
$services = array();

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $services[] = $row;
    }
}

// 3. Send to frontend
echo json_encode($services);
$conn->close();
?>